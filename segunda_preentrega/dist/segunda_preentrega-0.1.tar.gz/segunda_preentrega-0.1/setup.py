from setuptools import setup
from setuptools import setup, find_packages



# python setup.py sdist
# python -m pip install setuptools
# pip install setuptools

setup(
    name="segunda_preentrega",
    version="0.1",
    description="segunda preentrega coder house Python",
    author="Tomas",
    author_email="tommi.nazar@gmail.com",
    packages=find_packages(),
    
    
)